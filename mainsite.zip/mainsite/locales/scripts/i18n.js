class I18n {
  constructor() {
    this.languages = {
      en: { name: "English", flag: "🇬🇧", rtl: false },
      es: { name: "Español", flag: "🇪🇸", rtl: false },
      hi: { name: "हिन्दी", flag: "🇮🇳", rtl: false },
      ne: { name: "नेपाली", flag: "🇳🇵", rtl: false },
      pt: { name: "Português", flag: "🇵🇹", rtl: false },
      zh: { name: "中文", flag: "🇨🇳", rtl: false }
    };
    
    this.currentLang = localStorage.getItem('language') || 'en';
    this.translations = {};
    
    this.init();
  }

  async init() {
    await this.loadTranslations();
    this.applyTranslations();
    this.updateLanguageSwitcher();
    this.updateHtmlAttributes();
    this.setupEventListeners();
    
    // Watch for new elements added dynamically (MutationObserver)
    this.setupDynamicContentObserver();
  }

  async loadTranslations() {
    try {
      const page = window.location.pathname.split('/').pop().replace('.html', '') || 'index';

      // Load split translation files
      const [commonResp, pageResp] = await Promise.all([
        fetch(`locales/${this.currentLang}/common.json`),
        fetch(`locales/${this.currentLang}/${page}.json`)
      ]);

      const commonData = await commonResp.json();
      const pageData = await pageResp.json();
      this.translations = { ...commonData, ...pageData };

    } catch (error) {
      console.error('Translation loading failed:', error);
      if (this.currentLang !== 'en') {
        this.currentLang = 'en';
        await this.loadTranslations();
      }
    }
  }

  // Updated to accept a root element for scoped translation
  applyTranslations(root = document) {
    console.log('Applying translations to:', root);
    root.querySelectorAll('[data-i18n]').forEach(el => {
      const keys = el.dataset.i18n.split('.');
      let translation = this.translations;

      for (const key of keys) {
        translation = translation?.[key];
        if (translation === undefined) break;
      }

      if (translation !== undefined) {
        if (Array.isArray(translation)) {
          // Handle array translations (e.g., features lists)
          if (el.tagName === 'LI' && el.parentElement.tagName === 'UL') {
            const index = Array.from(el.parentElement.children).indexOf(el);
            if (translation[index]) {
              el.textContent = translation[index];
            }
          }
        } else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.placeholder = translation;
        } else if (el.tagName === 'META') {
          el.content = translation;
        } else if (el.hasAttribute('title')) {
          el.title = translation;
        } else if (el.hasAttribute('aria-label')) {
          el.setAttribute('aria-label', translation);
        } else {
          el.textContent = translation;
        }
      } else {
        console.warn('Missing translation for:', el.dataset.i18n);
      }
    });
  }

  updateLanguageSwitcher() {
    const langData = this.languages[this.currentLang];

    document.querySelectorAll('.language-switcher').forEach(switcher => {
      const button = switcher.querySelector('.language-switcher-button');
      const dropdown = switcher.querySelector('.language-dropdown');

      if (button) {
        const textSpan = button.querySelector('span:not(.flag-icon)');
        const flagSpan = button.querySelector('.flag-icon');

        if (textSpan) textSpan.textContent = langData.name;
        if (flagSpan) flagSpan.textContent = langData.flag;
      }

      if (dropdown) {
        dropdown.querySelectorAll('[data-lang]').forEach(option => {
          const lang = option.dataset.lang;
          option.classList.toggle('active', lang === this.currentLang);
        });
      }
    });
  }

  updateHtmlAttributes() {
    document.documentElement.lang = this.currentLang;
    document.documentElement.dir = this.languages[this.currentLang]?.rtl ? 'rtl' : 'ltr';
  }

  setupEventListeners() {
    document.addEventListener('click', (e) => {
      const langOption = e.target.closest('[data-lang]');
      if (langOption) {
        e.preventDefault();
        this.changeLanguage(langOption.dataset.lang);
      }
    });
  }

  // Watch for dynamically added content
  setupDynamicContentObserver() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1) { // Only process element nodes
            this.applyTranslations(node);
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  async changeLanguage(lang) {
    if (!this.languages[lang]) return;

    console.log(`Changing language to: ${lang}`);
    this.currentLang = lang;
    localStorage.setItem('language', lang);

    await this.loadTranslations();
    this.applyTranslations(); // Now re-translates the entire DOM
    this.updateLanguageSwitcher();
    this.updateHtmlAttributes();

    document.dispatchEvent(new CustomEvent('languageChanged', {
      detail: { language: lang }
    }));
  }
}

// Initialize and expose to window
document.addEventListener('DOMContentLoaded', () => {
  window.i18n = new I18n();
  window.changeLanguage = (lang) => window.i18n.changeLanguage(lang);
  
  // Manual trigger for testing (optional)
  console.log('i18n initialized. Available languages:', window.i18n.languages);
});