// ======================
// ACTIVE NAVIGATION ITEM HANDLER
// ======================
function setActiveNavItem() {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  
  // Set active state for desktop navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    const link = item.getAttribute('href');
    if (link === currentPage) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });
  
  // Set active state for mobile navigation
  document.querySelectorAll('.mobile-nav-item').forEach(item => {
    const link = item.getAttribute('href');
    if (link === currentPage) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });
}

// ======================
// ENHANCED MOBILE MENU TOGGLE
// ======================
function toggleMobileMenu() {
  const menuButton = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');
  const body = document.body;
  const lines = [
    document.getElementById('mobile-line-1'),
    document.getElementById('mobile-line-2'),
    document.getElementById('mobile-line-3')
  ];

  // Set initial aria attributes
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-controls', 'mobile-menu');

  menuButton.addEventListener('click', function() {
    const isExpanded = menuButton.getAttribute('aria-expanded') === 'true';
    
    // Toggle menu state with animations
    if (!isExpanded) {
      // Opening animation
      mobileMenu.classList.remove('hidden');
      setTimeout(() => {
        mobileMenu.style.maxHeight = mobileMenu.scrollHeight + 'px';
        mobileMenu.classList.add('open');
        menuButton.classList.add('active');
        
        // Animate hamburger to X
        lines[0].style.transform = 'translateY(8px) rotate(45deg)';
        lines[1].style.opacity = '0';
        lines[2].style.transform = 'translateY(-8px) rotate(-45deg)';
      }, 10);
      
      // Lock body scroll
      body.style.overflow = 'hidden';
    } else {
      // Closing animation
      mobileMenu.style.maxHeight = '0';
      menuButton.classList.remove('active');
      
      // Animate X to hamburger
      lines[0].style.transform = 'translateY(0) rotate(0)';
      lines[1].style.opacity = '1';
      lines[2].style.transform = 'translateY(0) rotate(0)';
      
      setTimeout(() => {
        mobileMenu.classList.remove('open');
        mobileMenu.classList.add('hidden');
        body.style.overflow = '';
      }, 300);
    }
    
    // Update aria attribute
    menuButton.setAttribute('aria-expanded', !isExpanded);
  });

  // Close menu when clicking on links
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.style.maxHeight = '0';
      menuButton.classList.remove('active');
      menuButton.setAttribute('aria-expanded', 'false');
      body.style.overflow = '';
      
      setTimeout(() => {
        mobileMenu.classList.remove('open');
        mobileMenu.classList.add('hidden');
      }, 300);
    });
  });
}

// ======================
// ENHANCED LANGUAGE SWITCHER
// ======================
function initializeLanguageSwitcher(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  container.innerHTML = `
    <div class="language-switcher relative">
      <button class="language-switcher-button flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-all duration-300" aria-expanded="false">
        <span class="flag-icon">🌐</span>
        <span class="language-label">English</span>
        <svg class="chevron-icon h-4 w-4 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      <div class="language-dropdown">
        <div class="py-1">
          <a href="#" data-lang="en" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇬🇧</span>
            <span>English</span>
          </a>
          <a href="#" data-lang="es" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇪🇸</span>
            <span>Español</span>
          </a>
          <a href="#" data-lang="hi" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇮🇳</span>
            <span>हिन्दी (Hindi)</span>
          </a>
          <a href="#" data-lang="ne" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇳🇵</span>
            <span>नेपाली (Nepali)</span>
          </a>
          <a href="#" data-lang="pt" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇵🇹</span>
            <span>Português</span>
          </a>
          <a href="#" data-lang="zh" class="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
            <span class="flag-icon mr-2">🇨🇳</span>
            <span>中文 (Chinese)</span>
          </a>
        </div>
      </div>
    </div>
  `;
  
  const button = container.querySelector('.language-switcher-button');
  const dropdown = container.querySelector('.language-dropdown');
  const chevron = container.querySelector('.chevron-icon');
  
  if (button && dropdown) {
    button.addEventListener('click', function(e) {
      e.stopPropagation();
      const isExpanded = button.getAttribute('aria-expanded') === 'true';
      
      // Toggle dropdown
      if (isExpanded) {
        dropdown.classList.remove('show');
        chevron.style.transform = 'rotate(0deg)';
      } else {
        dropdown.classList.add('show');
        chevron.style.transform = 'rotate(180deg)';
        
        // Ensure dropdown is fully visible on mobile
        if (window.innerWidth < 768) {
          const dropdownRect = dropdown.getBoundingClientRect();
          const viewportHeight = window.innerHeight;
          
          if (dropdownRect.bottom > viewportHeight) {
            dropdown.style.maxHeight = (viewportHeight - dropdownRect.top - 20) + 'px';
          }
        }
      }
      
      button.setAttribute('aria-expanded', !isExpanded);
    });
    
    // Handle language selection
    dropdown.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const lang = this.getAttribute('data-lang');
        const label = this.querySelector('span:not(.flag-icon)').textContent.trim();
        
        // Update button text
        container.querySelector('.language-label').textContent = label;
        
        // Close dropdown
        dropdown.classList.remove('show');
        chevron.style.transform = 'rotate(0deg)';
        button.setAttribute('aria-expanded', 'false');
        
        // Change language
        if (window.changeLanguage) {
          window.changeLanguage(lang);
        }
      });
    });
  }
}

// ======================
// SCROLL-TO-HIDE HEADER
// ======================
function setupHeaderScrollEffect() {
  const header = document.querySelector('header');
  let lastScroll = 0;
  const threshold = 100;
  
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
      header.style.transform = 'translateY(0)';
      header.classList.remove('scrolled');
    } else if (currentScroll > lastScroll && currentScroll > threshold) {
      // Scrolling down
      header.style.transform = 'translateY(-100%)';
      header.classList.add('scrolled');
    } else {
      // Scrolling up
      header.style.transform = 'translateY(0)';
      header.classList.add('scrolled');
    }
    
    lastScroll = currentScroll;
  });
}

// ======================
// INITIALIZATION
// ======================
document.addEventListener('DOMContentLoaded', function() {
  // Set active navigation item
  setActiveNavItem();
  
  // Initialize mobile menu
  toggleMobileMenu();
  
  // Initialize language switchers
  initializeLanguageSwitcher('language-switcher-container');
  initializeLanguageSwitcher('mobile-language-switcher');
  
  // Set up scroll effect
  setupHeaderScrollEffect();
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function(e) {
    // Language switcher
    document.querySelectorAll('.language-switcher').forEach(switcher => {
      const dropdown = switcher.querySelector('.language-dropdown');
      const button = switcher.querySelector('.language-switcher-button');
      
      if (!switcher.contains(e.target)) {
        dropdown.classList.remove('show');
        if (button) {
          button.setAttribute('aria-expanded', 'false');
          const chevron = button.querySelector('.chevron-icon');
          if (chevron) chevron.style.transform = 'rotate(0deg)';
        }
      }
    });
    
    // Mobile menu
    const mobileMenu = document.getElementById('mobile-menu');
    const menuButton = document.getElementById('mobile-menu-button');
    if (mobileMenu && menuButton && !mobileMenu.contains(e.target) && !menuButton.contains(e.target) && mobileMenu.classList.contains('open')) {
      mobileMenu.style.maxHeight = '0';
      menuButton.classList.remove('active');
      menuButton.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      
      setTimeout(() => {
        mobileMenu.classList.remove('open');
        mobileMenu.classList.add('hidden');
      }, 300);
    }
  });
  
  // Handle window resize
  window.addEventListener('resize', function() {
    // Recalculate mobile menu height if open
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu && mobileMenu.classList.contains('open')) {
      mobileMenu.style.maxHeight = mobileMenu.scrollHeight + 'px';
    }
  });
});

// ======================
// LANGUAGE CHANGE HANDLER
// ======================
document.addEventListener('languageChanged', function(e) {
  // Update active navigation items
  setActiveNavItem();
  
  // Update active language in switchers
  document.querySelectorAll('.language-dropdown a').forEach(link => {
    link.classList.toggle('active', link.getAttribute('data-lang') === e.detail.language);
  });
});