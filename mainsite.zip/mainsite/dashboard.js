import { 
  db, 
  collection, 
  getDocs, 
  doc, 
  updateDoc, 
  deleteDoc,
  query, 
  where, 
  orderBy, 
  auth, 
  signOut,
  serverTimestamp
} from './firebase.js';

// DOM Elements
const elements = {
  submissionsList: document.getElementById('submissions-list'),
  newsletterList: document.getElementById('newsletter-list'),
  logoutBtn: document.getElementById('logout-btn'),
  searchInput: document.getElementById('search-input'),
  statusFilter: document.getElementById('status-filter'),
  exportBtn: document.getElementById('export-btn'),
  loadingIndicator: document.getElementById('loading-indicator'),
  noResults: document.getElementById('no-results'),
  submissionCount: document.getElementById('submission-count'),
  confirmationModal: document.getElementById('confirmation-modal'),
  confirmActionBtn: document.getElementById('confirm-action-btn'),
  cancelActionBtn: document.getElementById('cancel-action-btn'),
  detailModal: document.getElementById('detail-modal'),
  closeDetailModal: document.getElementById('close-detail-modal'),
  detailContent: document.getElementById('detail-content'),
  toast: document.getElementById('toast'),
  modalTitle: document.getElementById('modal-title'),
  modalMessage: document.getElementById('modal-message')
};

// State
let state = {
  currentAction: null,
  currentDocId: null,
  allSubmissions: [],
  allNewsletters: [],
  isAdmin: false
};

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await initDashboard();
});

async function initDashboard() {
  try {
    // Verify authentication and admin status
    await verifyAdminStatus();
    setupEventListeners();
    await Promise.all([
      loadContactSubmissions(),
      loadNewsletterSubscriptions()
    ]);
  } catch (error) {
    console.error('Initialization error:', error);
    showToast('Failed to initialize dashboard', true);
  }
}

// Verify if user is admin
async function verifyAdminStatus() {
  const user = auth.currentUser;
  if (!user) {
    window.location.href = 'login.html';
    return;
  }
  
  try {
    const token = await user.getIdTokenResult();
    state.isAdmin = token.claims.admin === true;
    
    if (!state.isAdmin) {
      showToast('Admin privileges required', true);
      setTimeout(() => signOut(auth), 3000);
    }
  } catch (error) {
    console.error('Admin verification error:', error);
    showToast('Failed to verify admin status', true);
  }
}

// Event Listeners
function setupEventListeners() {
  elements.logoutBtn?.addEventListener('click', handleLogout);
  elements.searchInput?.addEventListener('input', debounce(filterSubmissions, 300));
  elements.statusFilter?.addEventListener('change', filterSubmissions);
  elements.exportBtn?.addEventListener('click', exportToCSV);
  elements.confirmActionBtn?.addEventListener('click', confirmAction);
  elements.cancelActionBtn?.addEventListener('click', cancelAction);
  elements.closeDetailModal?.addEventListener('click', () => toggleModal('detail-modal', false));
}

// Debounce function for search input
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// Load Contact Submissions
async function loadContactSubmissions() {
  try {
    showLoading(true);
    const q = query(collection(db, 'contacts'), orderBy('timestamp', 'desc'));
    const querySnapshot = await getDocs(q);
    
    state.allSubmissions = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      formattedDate: formatTimestamp(doc.data().timestamp)
    }));
    
    renderSubmissions(state.allSubmissions);
    updateSubmissionCount(state.allSubmissions.length);
  } catch (error) {
    console.error('Error loading submissions:', error);
    showToast('Failed to load submissions', true);
  } finally {
    showLoading(false);
  }
}

// Load Newsletter Subscriptions
async function loadNewsletterSubscriptions() {
  try {
    const q = query(collection(db, 'newsletters'), orderBy('timestamp', 'desc'));
    const querySnapshot = await getDocs(q);
    
    state.allNewsletters = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      formattedDate: formatTimestamp(doc.data().timestamp)
    }));
    
    renderNewsletters(state.allNewsletters);
  } catch (error) {
    console.error('Error loading newsletters:', error);
    showToast('Failed to load newsletter subscriptions', true);
  }
}

// Render Submissions with proper admin checks
function renderSubmissions(submissions) {
  elements.submissionsList.innerHTML = '';
  
  if (submissions.length === 0) {
    elements.noResults.classList.remove('hidden');
    return;
  }
  
  elements.noResults.classList.add('hidden');
  
  submissions.forEach(submission => {
    const statusColor = getStatusColor(submission.status);
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4 whitespace-nowrap">
        <div class="font-medium">${escapeHTML(submission.name)}</div>
      </td>
      <td class="px-6 py-4 whitespace-nowrap">
        <div class="text-gray-900">${escapeHTML(submission.email)}</div>
      </td>
      <td class="px-6 py-4 whitespace-nowrap">
        <div class="text-gray-900">${escapeHTML(submission.package || 'N/A')}</div>
      </td>
      <td class="px-6 py-4 whitespace-nowrap">
        <div class="text-gray-900">${escapeHTML(submission.budget || 'N/A')}</div>
      </td>
      <td class="px-6 py-4 whitespace-nowrap">
        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor}">
          ${escapeHTML(submission.status || 'New')}
        </span>
      </td>
      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${submission.formattedDate || 'N/A'}
      </td>
      <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <button data-action="view" data-id="${submission.id}" class="text-blue-600 hover:text-blue-900 mr-3">View</button>
        ${state.isAdmin ? `<button data-action="delete" data-id="${submission.id}" class="text-red-600 hover:text-red-900">Delete</button>` : ''}
      </td>
    `;
    
    elements.submissionsList.appendChild(row);
  });

  // Add event listeners
  document.querySelectorAll('[data-action="view"]').forEach(btn => {
    btn.addEventListener('click', (e) => showDetail(e.target.dataset.id));
  });

  document.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', (e) => showActionModal(e.target.dataset.id, 'delete'));
  });
}

// Render Newsletters with admin checks
function renderNewsletters(newsletters) {
  elements.newsletterList.innerHTML = '';
  
  newsletters.forEach(newsletter => {
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4 whitespace-nowrap">
        <div class="text-gray-900">${escapeHTML(newsletter.email)}</div>
      </td>
      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${newsletter.formattedDate || 'N/A'}
      </td>
      <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        ${state.isAdmin ? `<button data-action="delete-newsletter" data-id="${newsletter.id}" class="text-red-600 hover:text-red-900">Delete</button>` : ''}
      </td>
    `;
    
    elements.newsletterList.appendChild(row);
  });

  // Add event listeners
  document.querySelectorAll('[data-action="delete-newsletter"]').forEach(btn => {
    btn.addEventListener('click', (e) => showActionModal(e.target.dataset.id, 'delete-newsletter'));
  });
}

// Secure Delete Functionality
async function confirmAction() {
  if (!state.isAdmin) {
    showToast('Admin privileges required', true);
    return;
  }

  try {
    if (state.currentAction === 'delete') {
      const docRef = doc(db, 'contacts', state.currentDocId);
      const docSnap = await getDocs(docRef);
      
      if (!docSnap.exists()) {
        showToast('Submission not found', true);
        return;
      }

      await deleteDoc(docRef);
      showToast('Submission deleted successfully');
      await loadContactSubmissions();
    } else if (state.currentAction === 'delete-newsletter') {
      const docRef = doc(db, 'newsletters', state.currentDocId);
      const docSnap = await getDocs(docRef);
      
      if (!docSnap.exists()) {
        showToast('Subscription not found', true);
        return;
      }

      await deleteDoc(docRef);
      showToast('Newsletter subscription deleted successfully');
      await loadNewsletterSubscriptions();
    }
  } catch (error) {
    console.error('Error performing action:', error);
    
    let errorMessage = 'Failed to perform action';
    if (error.code === 'permission-denied') {
      errorMessage = 'You do not have permission to perform this action';
    } else if (error.code === 'not-found') {
      errorMessage = 'Document not found';
    }
    
    showToast(errorMessage, true);
  } finally {
    cancelAction();
  }
}

// Helper Functions
function formatTimestamp(timestamp) {
  if (!timestamp?.toDate) return 'N/A';
  const date = timestamp.toDate();
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function escapeHTML(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function toggleModal(modalId, show) {
  const modal = document.getElementById(modalId);
  if (show) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  } else {
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }
}

// Other existing functions (filterSubmissions, showDetail, updateStatus, etc.) remain the same
// ... [Previous helper functions remain unchanged]

// Initialize the dashboard
async function initializeDashboard() {
  await verifyAdminStatus();
  if (!state.isAdmin) return;
  
  setupEventListeners();
  await loadData();
}

// Export to CSV with proper escaping
async function exportToCSV() {
  if (!state.isAdmin) {
    showToast('Admin privileges required', true);
    return;
  }

  try {
    const dateString = new Date().toISOString().slice(0, 10);
    const filename = `submissions_${dateString}.csv`;
    
    // CSV header
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Name,Email,Phone,Package,Budget,Timeline,Status,Date,Message\n";
    
    // CSV rows
    state.allSubmissions.forEach(sub => {
      const row = [
        `"${(sub.name || '').replace(/"/g, '""')}"`,
        sub.email || '',
        sub.phone || '',
        sub.package || '',
        sub.budget || '',
        sub.timeline || '',
        sub.status || 'New',
        sub.formattedDate || '',
        `"${(sub.message || '').replace(/"/g, '""')}"`
      ].join(',');
      csvContent += row + "\n";
    });
    
    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast(`Exported ${state.allSubmissions.length} submissions`);
  } catch (error) {
    console.error('Export error:', error);
    showToast('Failed to export data', true);
  }
}

// Handle logout
async function handleLogout() {
  try {
    await signOut(auth);
    window.location.href = 'login.html';
  } catch (error) {
    console.error('Logout error:', error);
    showToast('Failed to logout', true);
  }
}