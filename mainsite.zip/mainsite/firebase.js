// Firebase v10.1.0 Modular SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-app.js";
import { 
  getFirestore,
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.1.0/firebase-firestore.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  sendPasswordResetEmail,
  setPersistence,
  browserSessionPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.1.0/firebase-auth.js";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from "https://www.gstatic.com/firebasejs/10.1.0/firebase-storage.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB6iJbA9YOC3YIojGEFrL5OkL1mloREBQs",
  authDomain: "sitegenify.firebaseapp.com",
  projectId: "sitegenify",
  storageBucket: "sitegenify.firebasestorage.app",
  messagingSenderId: "940375702731",
  appId: "1:940375702731:web:3994f74a99eedb4502ef4e",
  measurementId: "G-N5MSLQK1MW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Services
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);


// Add this to your firebase.js
export const isAdmin = async () => {
  const user = auth.currentUser;
  if (!user) return false;
  
  // Get the user's token and check for admin claim
  const token = await user.getIdTokenResult();
  return token.claims.admin === true;
};


// Export services and functions
export {
  // Core Services
  db,
  auth,
  storage,
  
  // Firestore Functions
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  
  // Auth Functions
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  sendPasswordResetEmail,
  setPersistence,
  browserSessionPersistence,
  browserLocalPersistence,
  
  // Storage Functions
  uploadBytes,
  getDownloadURL,
  deleteObject,
  ref
};