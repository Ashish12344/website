import { 
  auth, 
  signInWithEmailAndPassword, 
  onAuthStateChanged, 
  signOut,
  sendPasswordResetEmail,
  browserSessionPersistence,
  browserLocalPersistence,
  setPersistence
} from './firebase.js';

// Toast Notification
function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${isError ? 'error' : ''}`;
  toast.style.display = 'block';
  setTimeout(() => {
    toast.style.display = 'none';
  }, 3000);
}

// Toggle Password Visibility
function setupPasswordToggle() {
  const toggleBtn = document.getElementById('toggle-password');
  const passwordInput = document.getElementById('password');
  
  toggleBtn.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    toggleBtn.innerHTML = type === 'password' 
      ? '<i class="fas fa-eye text-gray-400 hover:text-gray-600"></i>' 
      : '<i class="fas fa-eye-slash text-gray-400 hover:text-gray-600"></i>';
  });
}

// Handle Login Form
function setupLoginForm() {
  const loginForm = document.getElementById('login-form');
  if (!loginForm) return;

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = loginForm.email.value.trim();
    const password = loginForm.password.value.trim();
    const rememberMe = loginForm['remember-me'].checked;
    
    // Show loading state
    const loginBtn = document.getElementById('login-button');
    const loginText = document.getElementById('login-text');
    const loginSpinner = document.getElementById('login-spinner');
    
    loginBtn.disabled = true;
    loginText.style.display = 'none';
    loginSpinner.style.display = 'inline-block';
    
    try {
      // Set persistence based on "Remember me" selection
      const persistenceType = rememberMe ? browserLocalPersistence : browserSessionPersistence;
      await setPersistence(auth, persistenceType);
      
      // Sign in user
      await signInWithEmailAndPassword(auth, email, password);
      
      // Redirect to dashboard
      window.location.href = 'dashboard.html';
    } catch (error) {
      console.error('Login error:', error);
      
      // Reset loading state
      loginBtn.disabled = false;
      loginText.style.display = 'inline-block';
      loginSpinner.style.display = 'none';
      
      // Show appropriate error message
      let errorMessage;
      switch (error.code) {
        case 'auth/invalid-email':
          errorMessage = 'Invalid email address format';
          break;
        case 'auth/user-disabled':
          errorMessage = 'This account has been disabled';
          break;
        case 'auth/user-not-found':
          errorMessage = 'No account found with this email';
          break;
        case 'auth/wrong-password':
          errorMessage = 'Incorrect password';
          break;
        case 'auth/too-many-requests':
          errorMessage = 'Too many attempts. Account temporarily locked. Try again later or reset your password.';
          break;
        default:
          errorMessage = 'Login failed. Please try again.';
      }
      
      showToast(errorMessage, true);
    }
  });
}

// Handle Password Reset
function setupPasswordReset() {
  const forgotPassword = document.getElementById('forgot-password');
  if (!forgotPassword) return;

  forgotPassword.addEventListener('click', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    
    if (!email) {
      showToast('Please enter your email address first', true);
      return;
    }
    
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showToast('Please enter a valid email address', true);
      return;
    }
    
    try {
      await sendPasswordResetEmail(auth, email);
      showToast(`Password reset email sent to ${email}`);
    } catch (error) {
      console.error('Password reset error:', error);
      
      let errorMessage = 'Failed to send reset email. Please try again.';
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email';
      }
      
      showToast(errorMessage, true);
    }
  });
}

// Handle Auth State Changes
function monitorAuthState() {
  onAuthStateChanged(auth, (user) => {
    const currentPage = window.location.pathname.split('/').pop();
    
    if (user) {
      console.log('User logged in:', user.email);
      
      // If on login page, redirect to dashboard
      if (currentPage === 'login.html' || currentPage === '') {
        window.location.href = 'dashboard.html';
      }
    } else {
      console.log('User logged out');
      
      // If on dashboard, redirect to login
      if (currentPage === 'dashboard.html') {
        window.location.href = 'login.html';
      }
    }
  });
}

// Handle Logout
function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  if (!logoutBtn) return;

  logoutBtn.addEventListener('click', async () => {
    try {
      await signOut(auth);
      showToast('Successfully logged out');
      window.location.href = 'login.html';
    } catch (error) {
      console.error('Logout error:', error);
      showToast('Failed to logout. Please try again.', true);
    }
  });
}

// Initialize all functionality
document.addEventListener('DOMContentLoaded', () => {
  setupPasswordToggle();
  setupLoginForm();
  setupPasswordReset();
  monitorAuthState();
  setupLogout();
});